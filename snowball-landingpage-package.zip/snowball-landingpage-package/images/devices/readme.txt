Images are used for iOS devices.

Visit Reverie Support Forum:
http://themefortress.com/discuss/forum/reverietheme/